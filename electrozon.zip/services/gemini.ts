
import { GoogleGenAI, Chat } from "@google/genai";
import { PRODUCTS } from "../constants";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

const SYSTEM_INSTRUCTION = `
You are the official AI assistant for ElectroZon, the premier electronics retailer in Morocco.
Your goal is to help users find the best electronics based on their needs.
You have access to the current catalog of products: ${JSON.stringify(PRODUCTS.map(p => ({ name: p.name, price: p.price, category: p.category })))}.
Always respond in Arabic unless the user speaks in another language.
Be professional, friendly, and helpful. Mention prices in Moroccan Dirhams (MAD).
If a user asks for a recommendation, pick one from the catalog.
`;

export class GeminiService {
  private chat: Chat;

  constructor() {
    this.chat = ai.chats.create({
      model: 'gemini-3-flash-preview',
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
  }

  async sendMessage(message: string) {
    try {
      const response = await this.chat.sendMessage({ message });
      return response.text;
    } catch (error) {
      console.error("Gemini Error:", error);
      return "عذراً، حدث خطأ ما. يرجى المحاولة لاحقاً.";
    }
  }
}

export const geminiService = new GeminiService();
