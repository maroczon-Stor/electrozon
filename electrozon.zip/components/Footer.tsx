
import React from 'react';
import { Facebook, Instagram, Twitter, Youtube, MapPin, Phone, Mail } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          
          {/* Brand */}
          <div className="space-y-6">
            <h2 className="text-3xl font-black tracking-tighter">
              ELECTRO<span className="text-orange-500">ZON</span>
            </h2>
            <p className="text-gray-400 text-sm leading-relaxed">
              إلكتروزون هو وجهتكم الأولى للحصول على أحدث التكنولوجيا والأجهزة الإلكترونية في المغرب. نلتزم بالجودة والسعر والخدمة المتميزة.
            </p>
            <div className="flex space-x-4 space-x-reverse">
              <a href="#" className="p-2 bg-gray-800 rounded-xl hover:bg-blue-600 transition-colors"><Facebook className="w-5 h-5" /></a>
              <a href="#" className="p-2 bg-gray-800 rounded-xl hover:bg-pink-600 transition-colors"><Instagram className="w-5 h-5" /></a>
              <a href="#" className="p-2 bg-gray-800 rounded-xl hover:bg-blue-400 transition-colors"><Twitter className="w-5 h-5" /></a>
              <a href="#" className="p-2 bg-gray-800 rounded-xl hover:bg-red-600 transition-colors"><Youtube className="w-5 h-5" /></a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-6">روابط سريعة</h3>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li><a href="#" className="hover:text-blue-500 transition-colors">من نحن</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">عروضنا</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">طرق الدفع</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">تتبع الطلب</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">سياسة الاسترجاع</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-xl font-bold mb-6">تواصل معنا</h3>
            <ul className="space-y-4 text-gray-400 text-sm">
              <li className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span>الدار البيضاء، شارع الزرقطوني، المغرب</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span>+212 522 000 000</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-blue-500 flex-shrink-0" />
                <span>contact@electrozon.ma</span>
              </li>
            </ul>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-xl font-bold mb-6">النشرة الإخبارية</h3>
            <p className="text-gray-400 text-sm mb-4">اشترك ليصلك جديد عروضنا الحصرية.</p>
            <div className="relative">
              <input 
                type="email" 
                placeholder="بريدك الإلكتروني" 
                className="w-full bg-gray-800 border-none rounded-xl py-3 px-4 text-sm focus:ring-2 focus:ring-blue-600 outline-none"
              />
              <button className="absolute left-1 top-1 bottom-1 px-4 bg-blue-600 rounded-lg text-xs font-bold hover:bg-blue-700 transition-colors">
                اشترك
              </button>
            </div>
          </div>

        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-gray-500 text-xs font-medium">
          <p>© 2024 ELECTROZON. جميع الحقوق محفوظة.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-white transition-colors">الشروط والأحكام</a>
            <a href="#" className="hover:text-white transition-colors">سياسة الخصوصية</a>
          </div>
          <div className="flex gap-2">
            <img src="https://upload.wikimedia.org/wikipedia/commons/5/5e/Visa_Inc._logo.svg" className="h-4 opacity-50 grayscale hover:grayscale-0 transition-all" alt="Visa" />
            <img src="https://upload.wikimedia.org/wikipedia/commons/2/2a/Mastercard-logo.svg" className="h-4 opacity-50 grayscale hover:grayscale-0 transition-all" alt="Mastercard" />
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
