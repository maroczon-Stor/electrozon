
import React from 'react';
import { CATEGORIES, getCategoryIcon } from '../constants';

const CategorySection: React.FC = () => {
  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-black text-gray-900">تصفح حسب الفئة</h2>
          <a href="#" className="text-blue-600 font-bold hover:underline">مشاهدة الكل</a>
        </div>
        
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-4">
          {CATEGORIES.map((cat) => (
            <div 
              key={cat.id} 
              className="group bg-white rounded-2xl p-6 text-center shadow-sm border border-gray-100 hover:shadow-md hover:border-blue-200 transition-all cursor-pointer"
            >
              <div className="w-16 h-16 mx-auto mb-4 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                {getCategoryIcon(cat.icon)}
              </div>
              <h3 className="font-bold text-gray-800 text-sm">{cat.title}</h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
