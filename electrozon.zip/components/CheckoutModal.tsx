
import React, { useState } from 'react';
import { X, Send, User, Phone, MapPin, Home } from 'lucide-react';
import { Product, CustomerInfo } from '../types';

interface CheckoutModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
}

const CheckoutModal: React.FC<CheckoutModalProps> = ({ product, isOpen, onClose }) => {
  const [formData, setFormData] = useState<CustomerInfo>({
    fullName: '',
    phone: '',
    city: '',
    address: '',
  });

  if (!isOpen || !product) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const message = `طلب جديد من ElectroZon:
---
المنتج: ${product.name}
السعر: ${product.price.toLocaleString()} د.م.
---
معلومات العميل:
الاسم: ${formData.fullName}
الهاتف: ${formData.phone}
المدينة: ${formData.city}
العنوان: ${formData.address}`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = `https://wa.me/212714044298?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
    onClose();
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-lg rounded-[2.5rem] overflow-hidden shadow-2xl animate-in slide-in-from-bottom-8 duration-300">
        {/* Header */}
        <div className="bg-blue-600 p-6 text-white relative">
          <button 
            onClick={onClose}
            className="absolute top-6 left-6 p-2 hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <h2 className="text-2xl font-black mb-1">إتمام الطلب</h2>
          <p className="text-blue-100 text-sm">يرجى ملء المعلومات التالية لتأكيد طلبك</p>
        </div>

        {/* Product Preview */}
        <div className="p-6 border-b border-gray-100 bg-gray-50 flex items-center gap-4">
          <img src={product.image} alt={product.name} className="w-16 h-16 rounded-xl object-cover shadow-sm" />
          <div>
            <h3 className="font-bold text-gray-800 line-clamp-1">{product.name}</h3>
            <p className="text-blue-600 font-black">{product.price.toLocaleString()} د.م.</p>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-8 space-y-4">
          <div className="space-y-4">
            <div className="relative">
              <label className="text-xs font-bold text-gray-500 mb-1 block mr-1">الاسم الكامل</label>
              <div className="relative">
                <input
                  required
                  type="text"
                  name="fullName"
                  value={formData.fullName}
                  onChange={handleChange}
                  placeholder="محمد بن علي"
                  className="w-full bg-gray-100 border-none rounded-2xl py-3 px-12 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
                />
                <User className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              </div>
            </div>

            <div className="relative">
              <label className="text-xs font-bold text-gray-500 mb-1 block mr-1">رقم الهاتف</label>
              <div className="relative">
                <input
                  required
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  placeholder="0612345678"
                  className="w-full bg-gray-100 border-none rounded-2xl py-3 px-12 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
                />
                <Phone className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="relative">
                <label className="text-xs font-bold text-gray-500 mb-1 block mr-1">المدينة</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleChange}
                    placeholder="الدار البيضاء"
                    className="w-full bg-gray-100 border-none rounded-2xl py-3 px-12 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
                  />
                  <MapPin className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>
              <div className="relative">
                <label className="text-xs font-bold text-gray-500 mb-1 block mr-1">العنوان</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    name="address"
                    value={formData.address}
                    onChange={handleChange}
                    placeholder="الحي، الشارع..."
                    className="w-full bg-gray-100 border-none rounded-2xl py-3 px-12 focus:ring-2 focus:ring-blue-500 outline-none transition-all text-sm"
                  />
                  <Home className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                </div>
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-orange-500 hover:bg-orange-600 text-white font-black py-4 rounded-2xl transition-all shadow-xl shadow-orange-500/30 flex items-center justify-center gap-2 mt-6 text-lg"
          >
            <Send className="w-5 h-5" />
            تأكيد الطلب عبر واتساب
          </button>
          <p className="text-[10px] text-gray-400 text-center">
            بالضغط على تأكيد، سيتم توجيهك إلى واتساب لإرسال معلومات طلبك مباشرة.
          </p>
        </form>
      </div>
    </div>
  );
};

export default CheckoutModal;
