
import React from 'react';

const Hero: React.FC = () => {
  return (
    <div className="relative overflow-hidden bg-white py-8 sm:py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Main Slider Area */}
          <div className="lg:col-span-2 relative h-[300px] sm:h-[450px] rounded-3xl overflow-hidden shadow-2xl group">
            <img 
              src="https://picsum.photos/seed/promo/1200/800" 
              alt="Promo Banner" 
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-black/70 via-black/20 to-transparent flex flex-col justify-center p-8 sm:p-12">
              <span className="text-orange-500 font-bold mb-2 inline-block px-3 py-1 bg-orange-500/20 rounded-full w-fit">عروض رمضان</span>
              <h2 className="text-3xl sm:text-5xl font-black text-white mb-4 leading-tight">
                أحدث التكنولوجيا <br/> بأفضل الأسعار في المغرب
              </h2>
              <p className="text-gray-200 mb-8 max-w-md text-sm sm:text-base">
                استمتع بخصومات تصل إلى 40% على جميع الهواتف الذكية والأجهزة المنزلية المختارة. توصيل مجاني وسريع لجميع المدن.
              </p>
              <div className="flex gap-4">
                <button className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full transition-all shadow-lg hover:shadow-blue-500/50">
                  تسوق الآن
                </button>
                <button className="bg-white/20 hover:bg-white/30 text-white backdrop-blur-md font-bold py-3 px-8 rounded-full transition-all border border-white/30">
                  شاهد المزيد
                </button>
              </div>
            </div>
          </div>

          {/* Side Promos */}
          <div className="flex flex-col gap-6">
            <div className="relative h-[140px] sm:h-[212px] rounded-3xl overflow-hidden shadow-lg group">
              <img src="https://picsum.photos/seed/watch/600/400" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="Watch" />
              <div className="absolute inset-0 bg-black/40 p-6 flex flex-col justify-end">
                <h3 className="text-xl font-bold text-white">ساعات ذكية</h3>
                <p className="text-orange-400 text-sm font-bold">ابتداءً من 299 درهم</p>
              </div>
            </div>
            <div className="relative h-[140px] sm:h-[212px] rounded-3xl overflow-hidden shadow-lg group">
              <img src="https://picsum.photos/seed/gaming/600/400" className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" alt="Gaming" />
              <div className="absolute inset-0 bg-blue-900/40 p-6 flex flex-col justify-end">
                <h3 className="text-xl font-bold text-white">عالم الألعاب</h3>
                <p className="text-yellow-400 text-sm font-bold">تخفيضات تصل لـ 20%</p>
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Hero;
