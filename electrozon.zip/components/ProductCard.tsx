
import React from 'react';
import { Product } from '../types';
import { Star, ShoppingCart, Heart, Send } from 'lucide-react';

interface ProductCardProps {
  product: Product;
  onBuy?: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onBuy }) => {
  return (
    <div className="group bg-white rounded-2xl p-4 transition-all duration-300 hover:shadow-xl hover:-translate-y-1 relative border border-gray-100 h-full flex flex-col">
      {/* Badges */}
      <div className="absolute top-4 left-4 z-10 flex flex-col gap-2">
        {product.isNew && (
          <span className="bg-green-500 text-white text-[10px] font-bold px-2 py-1 rounded-md uppercase">جديد</span>
        )}
        {product.discount && (
          <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-md">-{product.discount}</span>
        )}
      </div>
      
      <button className="absolute top-4 right-4 z-10 p-2 bg-white/80 backdrop-blur-sm rounded-full shadow-sm text-gray-400 hover:text-red-500 transition-colors">
        <Heart className="w-5 h-5" />
      </button>

      {/* Image */}
      <div className="aspect-square rounded-xl overflow-hidden mb-4 bg-gray-50 flex-shrink-0">
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
        />
      </div>

      {/* Info */}
      <div className="flex flex-col flex-1">
        <p className="text-[10px] text-gray-400 mb-1 font-medium uppercase tracking-wider">{product.category}</p>
        <h3 className="text-sm font-bold text-gray-800 line-clamp-2 group-hover:text-blue-600 transition-colors mb-2 h-10">
          {product.name}
        </h3>
        
        <div className="flex items-center gap-1 mb-3">
          <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
          <span className="text-[10px] font-bold text-gray-600">{product.rating}</span>
        </div>

        <div className="mt-auto pt-2 border-t border-gray-50">
          <div className="mb-3">
            <div className="flex items-center gap-2">
              <span className="text-base font-black text-blue-600">{product.price.toLocaleString()} د.م.</span>
            </div>
            {product.oldPrice && (
              <span className="text-[10px] text-gray-400 line-through">{product.oldPrice.toLocaleString()} د.م.</span>
            )}
          </div>
          
          <button 
            onClick={() => onBuy?.(product)}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2.5 px-4 rounded-xl transition-all shadow-md hover:shadow-blue-200 flex items-center justify-center gap-2 text-sm font-bold"
          >
            <Send className="w-4 h-4" />
            أطلب الآن
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
