
import React from 'react';
import { Search, ShoppingCart, User, Menu, Heart } from 'lucide-react';

const Navbar: React.FC = () => {
  return (
    <nav className="sticky top-0 z-50 glass border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 sm:h-20">
          {/* Logo */}
          <div className="flex-shrink-0 flex items-center">
            <h1 className="text-2xl sm:text-3xl font-black text-blue-600 tracking-tighter">
              ELECTRO<span className="text-orange-500">ZON</span>
            </h1>
          </div>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-lg mx-8">
            <div className="relative w-full">
              <input 
                type="text" 
                placeholder="ابحث عن هاتف، تلفزيون، حاسوب..." 
                className="w-full bg-gray-100 border-none rounded-full py-2.5 px-6 pr-12 focus:ring-2 focus:ring-blue-500 transition-all outline-none"
              />
              <Search className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
            </div>
          </div>

          {/* Icons */}
          <div className="flex items-center space-x-2 sm:space-x-4 space-x-reverse">
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors md:hidden">
              <Search className="w-6 h-6 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors hidden sm:block">
              <Heart className="w-6 h-6 text-gray-600" />
            </button>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
              <User className="w-6 h-6 text-gray-600" />
            </button>
            <div className="relative">
              <button className="p-2 hover:bg-gray-100 rounded-full transition-colors">
                <ShoppingCart className="w-6 h-6 text-gray-600" />
              </button>
              <span className="absolute top-0 right-0 bg-orange-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full ring-2 ring-white">2</span>
            </div>
            <button className="p-2 hover:bg-gray-100 rounded-full transition-colors lg:hidden">
              <Menu className="w-6 h-6 text-gray-600" />
            </button>
          </div>
        </div>
      </div>
      
      {/* Sub-nav Category Links - Desktop */}
      <div className="hidden lg:block border-t border-gray-100">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-center space-x-8 space-x-reverse text-sm font-semibold text-gray-600">
          <a href="#" className="hover:text-blue-600 transition-colors">جميع الفئات</a>
          <a href="#" className="hover:text-blue-600 transition-colors">عروض حصرية</a>
          <a href="#" className="hover:text-blue-600 transition-colors">الهواتف</a>
          <a href="#" className="hover:text-blue-600 transition-colors">الحواسيب</a>
          <a href="#" className="hover:text-blue-600 transition-colors">تلفزيونات</a>
          <a href="#" className="hover:text-blue-600 transition-colors">منزل ذكي</a>
          <a href="#" className="text-orange-500 hover:text-orange-600 transition-colors">وصل حديثاً 🔥</a>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
